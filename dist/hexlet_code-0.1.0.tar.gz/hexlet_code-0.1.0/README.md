### Hexlet tests and linter status:
[![Actions Status](https://github.com/jespy666/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/jespy666/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/dacd2d1aee6ed66ab21e/maintainability)](https://codeclimate.com/github/jespy666/python-project-49/maintainability)
[![asciicast](https://asciinema.org/a/559421.svg)](https://asciinema.org/a/559421)
[![asciicast](https://asciinema.org/a/559499.svg)](https://asciinema.org/a/559499)
[![asciicast](https://asciinema.org/a/559669.svg)](https://asciinema.org/a/559669)

